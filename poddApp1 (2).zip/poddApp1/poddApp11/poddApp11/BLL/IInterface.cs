﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace poddApp11.DL
{
    interface IInterface
    {
        string PoddTitel { get; set; }
    }
}
