﻿namespace poddApp11.PL
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listViewPoddar = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.listViewPoddarAvsnitt = new System.Windows.Forms.ListView();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.textBoxUrl = new System.Windows.Forms.TextBox();
            this.comboBoxUppdatering = new System.Windows.Forms.ComboBox();
            this.comboBoxKategori = new System.Windows.Forms.ComboBox();
            this.textBoxKategori = new System.Windows.Forms.TextBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.buttonLaggTillPodd = new System.Windows.Forms.Button();
            this.buttonSparaPodd = new System.Windows.Forms.Button();
            this.buttonTaBortPodd = new System.Windows.Forms.Button();
            this.buttonLaggTillKat = new System.Windows.Forms.Button();
            this.buttonSparaKat = new System.Windows.Forms.Button();
            this.buttonTaBortKat = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // listViewPoddar
            // 
            this.listViewPoddar.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4});
            this.listViewPoddar.HideSelection = false;
            this.listViewPoddar.Location = new System.Drawing.Point(44, 31);
            this.listViewPoddar.Name = "listViewPoddar";
            this.listViewPoddar.Size = new System.Drawing.Size(338, 169);
            this.listViewPoddar.TabIndex = 0;
            this.listViewPoddar.UseCompatibleStateImageBehavior = false;
            this.listViewPoddar.View = System.Windows.Forms.View.Details;
            this.listViewPoddar.ItemActivate += new System.EventHandler(this.listViewPoddar_ItemActivate);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Namn";
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Avsnitt";
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Frekvens";
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Kategori";
            // 
            // listViewPoddarAvsnitt
            // 
            this.listViewPoddarAvsnitt.HideSelection = false;
            this.listViewPoddarAvsnitt.Location = new System.Drawing.Point(44, 318);
            this.listViewPoddarAvsnitt.Name = "listViewPoddarAvsnitt";
            this.listViewPoddarAvsnitt.Size = new System.Drawing.Size(360, 120);
            this.listViewPoddarAvsnitt.TabIndex = 1;
            this.listViewPoddarAvsnitt.UseCompatibleStateImageBehavior = false;
            this.listViewPoddarAvsnitt.ItemActivate += new System.EventHandler(this.listViewPoddarAvsnitt_ItemActivate);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(481, 31);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(292, 134);
            this.listBox1.TabIndex = 2;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.lbKategorier_SelectedIndexChanged);
            this.listBox1.Leave += new System.EventHandler(this.listBox1_Leave);
            // 
            // textBoxUrl
            // 
            this.textBoxUrl.Location = new System.Drawing.Point(44, 230);
            this.textBoxUrl.Name = "textBoxUrl";
            this.textBoxUrl.Size = new System.Drawing.Size(107, 20);
            this.textBoxUrl.TabIndex = 3;
            // 
            // comboBoxUppdatering
            // 
            this.comboBoxUppdatering.FormattingEnabled = true;
            this.comboBoxUppdatering.Location = new System.Drawing.Point(181, 229);
            this.comboBoxUppdatering.Name = "comboBoxUppdatering";
            this.comboBoxUppdatering.Size = new System.Drawing.Size(121, 21);
            this.comboBoxUppdatering.TabIndex = 4;
            // 
            // comboBoxKategori
            // 
            this.comboBoxKategori.FormattingEnabled = true;
            this.comboBoxKategori.Location = new System.Drawing.Point(308, 230);
            this.comboBoxKategori.Name = "comboBoxKategori";
            this.comboBoxKategori.Size = new System.Drawing.Size(121, 21);
            this.comboBoxKategori.TabIndex = 5;
            // 
            // textBoxKategori
            // 
            this.textBoxKategori.Location = new System.Drawing.Point(481, 180);
            this.textBoxKategori.Name = "textBoxKategori";
            this.textBoxKategori.Size = new System.Drawing.Size(292, 20);
            this.textBoxKategori.TabIndex = 6;
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(481, 318);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(307, 120);
            this.richTextBox1.TabIndex = 7;
            this.richTextBox1.Text = "";
            // 
            // buttonLaggTillPodd
            // 
            this.buttonLaggTillPodd.Location = new System.Drawing.Point(109, 272);
            this.buttonLaggTillPodd.Name = "buttonLaggTillPodd";
            this.buttonLaggTillPodd.Size = new System.Drawing.Size(75, 23);
            this.buttonLaggTillPodd.TabIndex = 8;
            this.buttonLaggTillPodd.Text = "Ny";
            this.buttonLaggTillPodd.UseVisualStyleBackColor = true;
            this.buttonLaggTillPodd.Click += new System.EventHandler(this.buttonLaggTillPodd_Click);
            // 
            // buttonSparaPodd
            // 
            this.buttonSparaPodd.Location = new System.Drawing.Point(217, 272);
            this.buttonSparaPodd.Name = "buttonSparaPodd";
            this.buttonSparaPodd.Size = new System.Drawing.Size(75, 23);
            this.buttonSparaPodd.TabIndex = 9;
            this.buttonSparaPodd.Text = "Spara";
            this.buttonSparaPodd.UseVisualStyleBackColor = true;
            this.buttonSparaPodd.Click += new System.EventHandler(this.buttonSparaPodd_Click);
            // 
            // buttonTaBortPodd
            // 
            this.buttonTaBortPodd.Location = new System.Drawing.Point(308, 272);
            this.buttonTaBortPodd.Name = "buttonTaBortPodd";
            this.buttonTaBortPodd.Size = new System.Drawing.Size(75, 23);
            this.buttonTaBortPodd.TabIndex = 10;
            this.buttonTaBortPodd.Text = "Tabort";
            this.buttonTaBortPodd.UseVisualStyleBackColor = true;
            this.buttonTaBortPodd.Click += new System.EventHandler(this.buttonTaBortPodd_Click);
            // 
            // buttonLaggTillKat
            // 
            this.buttonLaggTillKat.Location = new System.Drawing.Point(525, 209);
            this.buttonLaggTillKat.Name = "buttonLaggTillKat";
            this.buttonLaggTillKat.Size = new System.Drawing.Size(75, 23);
            this.buttonLaggTillKat.TabIndex = 11;
            this.buttonLaggTillKat.Text = "Ny";
            this.buttonLaggTillKat.UseVisualStyleBackColor = true;
            this.buttonLaggTillKat.Click += new System.EventHandler(this.buttonLaggTillKat_Click);
            // 
            // buttonSparaKat
            // 
            this.buttonSparaKat.Location = new System.Drawing.Point(617, 209);
            this.buttonSparaKat.Name = "buttonSparaKat";
            this.buttonSparaKat.Size = new System.Drawing.Size(75, 23);
            this.buttonSparaKat.TabIndex = 12;
            this.buttonSparaKat.Text = "Spara";
            this.buttonSparaKat.UseVisualStyleBackColor = true;
            this.buttonSparaKat.Click += new System.EventHandler(this.btnSparaKat_Click);
            // 
            // buttonTaBortKat
            // 
            this.buttonTaBortKat.Location = new System.Drawing.Point(698, 209);
            this.buttonTaBortKat.Name = "buttonTaBortKat";
            this.buttonTaBortKat.Size = new System.Drawing.Size(75, 23);
            this.buttonTaBortKat.TabIndex = 13;
            this.buttonTaBortKat.Text = "Ta bort";
            this.buttonTaBortKat.UseVisualStyleBackColor = true;
            this.buttonTaBortKat.Click += new System.EventHandler(this.buttonTaBortKat_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(44, 299);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 13);
            this.label1.TabIndex = 14;
            this.label1.Text = "Avsnitt";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(305, 209);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 13);
            this.label2.TabIndex = 15;
            this.label2.Text = "Kategori";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(178, 209);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(114, 13);
            this.label3.TabIndex = 16;
            this.label3.Text = "UppdateringsFrekvens";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(41, 209);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(20, 13);
            this.label4.TabIndex = 17;
            this.label4.Text = "Url";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(803, 451);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonTaBortKat);
            this.Controls.Add(this.buttonSparaKat);
            this.Controls.Add(this.buttonLaggTillKat);
            this.Controls.Add(this.buttonTaBortPodd);
            this.Controls.Add(this.buttonSparaPodd);
            this.Controls.Add(this.buttonLaggTillPodd);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.textBoxKategori);
            this.Controls.Add(this.comboBoxKategori);
            this.Controls.Add(this.comboBoxUppdatering);
            this.Controls.Add(this.textBoxUrl);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.listViewPoddarAvsnitt);
            this.Controls.Add(this.listViewPoddar);
            this.Name = "Form1";
            this.Text = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView listViewPoddar;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ListView listViewPoddarAvsnitt;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.TextBox textBoxUrl;
        private System.Windows.Forms.ComboBox comboBoxUppdatering;
        private System.Windows.Forms.ComboBox comboBoxKategori;
        private System.Windows.Forms.TextBox textBoxKategori;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Button buttonLaggTillPodd;
        private System.Windows.Forms.Button buttonSparaPodd;
        private System.Windows.Forms.Button buttonTaBortPodd;
        private System.Windows.Forms.Button buttonLaggTillKat;
        private System.Windows.Forms.Button buttonSparaKat;
        private System.Windows.Forms.Button buttonTaBortKat;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}